#include <Arduino.h>
#include <HardwareSerial.h>
#include <Math.h>
#include <stdarg.h>
#include "VPW.h"


J1850::J1850() {

}
uint16_t vpwMSG_size;
uint8_t VPW_Buf[255];
/*
   Initialize serial bus and other necessary information.

   @access	public
   @param	object	HardwareSerial reference - Typically Serial1 on Arduino and Teensy
   @return	void
*/
void J1850::vpwStart(int SelectSerial) {

  // VPW = serial; //save passed serial to our private variable so it can be called whenever.

  if (SelectSerial == 0)
  {

    VPW = &Serial;
  }
  else if (SelectSerial == 1)
  {
    //Serial1.begin(115200);
    VPW = &Serial1;
  }
  else if (SelectSerial == 2)
  {
    //Serial1.begin(115200);
    VPW = &Serial2;
  } else if (SelectSerial == 3)
  {
    usbSerial = true;
    //Serial1.begin(115200);
    VPW = &Serial3;
  }

  VPW->begin(vpwBaud);//start serial at the private baud rate 115200

}


void J1850::vpwDebug(int debugSerial) {
  debugPrints = true;
  if  (debugSerial == 0) {
    Serial.begin(vpwBaud);
    Serial.println("USB Serial Init");
  }
}

void J1850::printCR() {
  usbSerial = true;
}

bool J1850::WaitForSerial(uint16_t waitTime)
{
  uint32_t StartMil = millis();
  while ((millis() - StartMil) < waitTime)
  {
    if (VPW->available() > 0) {
      return true;
    }
  }
  return false;
}

bool J1850::vpwAvailable(uint16_t timeout) {
  if (VPW->available() > 0)
  {
    vpwMSG_size = 0x00;
    int  zeroByte = VPW->read();
    if (WaitForSerial(timeout) == false) {
      return false;
    }
    uint8_t thisSize =   VPW->read();
    vpwMSG_size = thisSize + 1;
    VPW_Buf[0] = thisSize;
    for (uint16_t i = 1; i < thisSize + 1 ; i++)
    {
      if (WaitForSerial(timeout) == false) {
        return true;
      }
      VPW_Buf[i] = VPW->read();// create offset to incluse message size
    }
    return true;
  }
  return false;
}

//void J1850::readVPW_msg() {
//  for (uint16_t i = 0; i < vpwMSG_size; i++)
//  {
//    if (WaitForSerial() == false) {
//      return false;
//    }
//    VPW_Buf[i] = VPW->read();
//  }
//}









/*
   Transmit to the serial port.

   @access	private
   @return	void
*/
//void J1850::vpwTX(uint16_t numBytes, uint8_t *TempBuf) {
void J1850::vpwTX(uint8_t *TempBuf) {

  int len = TempBuf[0] + 2; // the message uses a leading 0x00 followed by the message size, the message size does NOT include the null byte or the size byte making it message size + 2 every time.
  uint8_t newBuf[len];
  newBuf[0] = 0x00;
  for (uint16_t i = 0; i < len; ++i) {
    newBuf[i + 1] = TempBuf[i];
  }


  for (uint16_t i = 0; i < len; ++i) { //loop mc loopy
    while (  VPW->availableForWrite() == 0) {} //do fuckall while no bytes free to write with
  //  uint8_t tempbyte = newBuf[i];
    VPW->write(newBuf[i]); //write bitch
  }

  if (debugPrints) {
    char MSG[128];
    Serial.print(" VPW txMsg: ");
    for (uint16_t i = 0; i < len; i++)
    {
      sprintf(MSG,  " 0x%.2X", TempBuf[i]);
      Serial.print(MSG);
    }
    Serial.println("");
  }
  if (usbSerial == true) {
    VPW->write(10);
  }
}
