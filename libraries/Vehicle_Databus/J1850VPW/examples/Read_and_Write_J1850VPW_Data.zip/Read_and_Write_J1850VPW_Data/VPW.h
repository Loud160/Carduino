#ifndef VPW_H
#define VPW_H

class J1850 {

  public:
    J1850(); //initializer - you could pass the serial parameter here also if updated for it
    void vpwStart(int SelectSerial); //pass serial wanted as a pointer to the function VPWStart(This is then saved to the private VPW variable below)
    //	void vpwTX(uint16_t numBytes, uint8_t *TempBuf); //send data command
    void vpwTX(uint8_t *TempBuf); //send data command
    void vpwDebug(int debugSerial);
    void printCR();
    bool WaitForSerial(uint16_t waitTime);
    bool vpwAvailable(uint16_t timeout);
    //   void readVPW_msg();
    uint8_t vpwMSG_size;
    uint8_t VPW_Buf[255];

  private:
    HardwareSerial *VPW;
    uint32_t  vpwBaud = 115200; //baud rate private variable
    boolean usbSerial = false;// if the USB Serial is used, assume messages are being debugged so add a new ling after each message for readability
    boolean debugPrints = false;

};

#endif
