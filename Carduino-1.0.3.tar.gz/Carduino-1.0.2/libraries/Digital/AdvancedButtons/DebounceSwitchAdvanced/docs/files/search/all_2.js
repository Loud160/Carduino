var searchData=
[
  ['changed_5',['changed',['../class_debouncer.html#a1bbd627f9d8809b5ee9e64e9fb21e248',1,'Debouncer']]],
  ['currentduration_6',['currentDuration',['../class_debouncer.html#a883645ca26b4df6e5823586432104d11',1,'Debouncer']]]
];
